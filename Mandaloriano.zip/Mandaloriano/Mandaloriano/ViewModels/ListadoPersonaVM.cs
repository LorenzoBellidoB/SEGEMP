﻿using BL;
using ENT;

namespace Mandaloriano.ViewModels
{
    public class ListadoPersonaVM
    {
        public List<ClsMision> Listado {  get; set; } 
        public ClsMision MisionSelected {  get; set; }

    }
}
