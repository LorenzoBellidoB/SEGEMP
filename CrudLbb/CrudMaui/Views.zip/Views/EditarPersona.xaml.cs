namespace CrudMaui.Views;

public partial class EditarPersona : ContentPage
{
	public EditarPersona()
	{
		InitializeComponent();
	}
}