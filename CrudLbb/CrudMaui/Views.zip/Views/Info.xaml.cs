namespace CrudMaui.Views;

public partial class Info : ContentPage
{
	public Info()
	{
		InitializeComponent();
	}
}