namespace CrudMaui.Views;

public partial class CrearPersona : ContentPage
{
	public CrearPersona()
	{
		InitializeComponent();
	}
}