namespace CrudMaui.Views;

public partial class Departamentos : ContentPage
{
	public Departamentos()
	{
		InitializeComponent();
	}
}