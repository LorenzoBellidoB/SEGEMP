namespace CrudMaui.Views;

public partial class Personas : ContentPage
{
	public Personas()
	{
		InitializeComponent();
	}

	private void ImageButton_Clicked(object sender, EventArgs e)
    {
        
    }
}